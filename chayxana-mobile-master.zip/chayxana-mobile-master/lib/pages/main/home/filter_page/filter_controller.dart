import 'package:get/get.dart';

class FilterController extends GetxController {
  /// #Nasibali
}