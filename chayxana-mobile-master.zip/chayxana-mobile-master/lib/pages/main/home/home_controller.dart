import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

class HomeController extends GetxController {
  /// #Nasibali
  late YandexMapController yandexMapController;
  TextEditingController searchTextController = TextEditingController();
}
