import 'package:get/get.dart';

class GalleryController extends GetxController {
  /// #Otabek
}