import 'package:get/get.dart';

class ResultController extends GetxController {
  /// #Doniyor
  bool bookingCheck = true;
}