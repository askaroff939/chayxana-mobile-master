import 'package:flutter/material.dart';

class AddCardPage extends StatelessWidget {
  static const String id = "/add_card_page";
  const AddCardPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      /// #Doniyor
    );
  }
}
