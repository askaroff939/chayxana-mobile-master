import 'package:get/get.dart';

class AddCardController extends GetxController {
  /// #Doniyor
}