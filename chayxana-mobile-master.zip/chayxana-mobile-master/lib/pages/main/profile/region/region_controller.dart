import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class RegionController extends GetxController {
  List region = [
    "Tashkent",
    "Andijon",
    "Buxoro",
    "Guliston",
    "Jizzah",
    "Samarqand",
    "Namangan",
    "Farg'ona",
    "Xorazm",
    "Qashqadaryo",
    "Surxandaryo",
    "Navoiy",
    "Qoraqalpog'iston"
  ];
  late Widget dividerChecker;
}