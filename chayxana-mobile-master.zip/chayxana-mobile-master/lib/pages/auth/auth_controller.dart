import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AuthController extends GetxController {
  static TextEditingController fullNameController = TextEditingController();
  static TextEditingController phoneController = TextEditingController();

}