import 'package:flutter/material.dart';

class ThemeService {
  // Colors
  // ...
  static Color colorBackGroundWhite = Colors.white;
  static Color colorIconButtonBlack = Colors.black;

  // Font Family
  static String montserrat = "Montserrat-Medium";
}
